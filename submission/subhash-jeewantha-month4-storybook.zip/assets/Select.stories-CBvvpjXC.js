import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./jsx-runtime-4ahyPWF4.js";import{n,t as r}from"./Select-D0Gj5hEW.js";var i,a,o,s,c,l;function u(){return(u=e((()=>{n(),i=t(),a={title:`Components/Select`,component:r,args:{label:`Role`,options:[{value:`admin`,label:`Admin`},{value:`editor`,label:`Editor`},{value:`user`,label:`User`}]},decorators:[e=>(0,i.jsx)(`div`,{className:`max-w-sm`,children:e()})]},o={args:{placeholder:`All roles`}},s={args:{label:`Roles`,multiple:!0,defaultValue:[`admin`,`editor`]}},c={args:{placeholder:`Choose…`,error:`Choose a role`}},l=[`Single`,`MultiSelect`,`WithError`],o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    placeholder: 'All roles'
  }
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Roles',
    multiple: true,
    defaultValue: ['admin', 'editor']
  }
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    placeholder: 'Choose…',
    error: 'Choose a role'
  }
}`,...c.parameters?.docs?.source}}}})))()}u();export{s as MultiSelect,o as Single,c as WithError,l as __namedExportsOrder,a as default};