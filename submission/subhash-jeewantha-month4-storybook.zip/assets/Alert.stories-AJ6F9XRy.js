import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./jsx-runtime-4ahyPWF4.js";import{n,t as r}from"./cn-CRapKfbA.js";import{a as i,d as a,l as o,o as s,r as c,u as l}from"./icons-qBvd0GBy.js";function u({variant:e=`info`,title:t,children:n,onDismiss:i,className:a}){let{box:o,Icon:s,label:c}=f[e];return(0,d.jsxs)(`div`,{role:e===`error`||e===`warning`?`alert`:`status`,className:r(`flex gap-3 rounded-md border p-4`,o,a),children:[(0,d.jsx)(s,{className:`mt-0.5 h-5 w-5 shrink-0`}),(0,d.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,d.jsxs)(`p`,{className:`font-semibold`,children:[(0,d.jsxs)(`span`,{className:`sr-only`,children:[c,`: `]}),t]}),n&&(0,d.jsx)(`div`,{className:r(`text-sm`,t&&`mt-1`),children:n})]}),i&&(0,d.jsx)(`button`,{type:`button`,onClick:i,"aria-label":`Dismiss`,className:`-m-1 h-8 w-8 shrink-0 rounded-md p-1.5 hover:bg-black/5 focus-visible:ring-2 focus-visible:ring-current focus-visible:outline-none`,children:(0,d.jsx)(l,{className:`h-5 w-5`})})]})}var d,f;function p(){return(p=e((()=>{n(),a(),d=t(),f={info:{box:`border-blue-300 bg-blue-50 text-blue-900 dark:border-blue-800 dark:bg-blue-950 dark:text-blue-100`,Icon:s,label:`Information`},success:{box:`border-green-300 bg-green-50 text-green-900 dark:border-green-800 dark:bg-green-950 dark:text-green-100`,Icon:c,label:`Success`},warning:{box:`border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-100`,Icon:o,label:`Warning`},error:{box:`border-red-300 bg-red-50 text-red-900 dark:border-red-800 dark:bg-red-950 dark:text-red-100`,Icon:i,label:`Error`}},u.__docgenInfo={description:`Errors and warnings use role="alert" (announced immediately); info and success use
role="status" (announced politely). The variant is also given in text, not only by colour.`,methods:[],displayName:`Alert`,props:{variant:{required:!1,tsType:{name:`union`,raw:`'info' | 'success' | 'warning' | 'error'`,elements:[{name:`literal`,value:`'info'`},{name:`literal`,value:`'success'`},{name:`literal`,value:`'warning'`},{name:`literal`,value:`'error'`}]},description:``,defaultValue:{value:`'info'`,computed:!1}},title:{required:!1,tsType:{name:`string`},description:``},children:{required:!1,tsType:{name:`ReactNode`},description:``},onDismiss:{required:!1,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:``},className:{required:!1,tsType:{name:`string`},description:``}}}})))()}var m,h,g,_,v,y,b,x,S;function C(){return(C=e((()=>{p(),m=t(),{fn:h}=__STORYBOOK_MODULE_TEST__,g={title:`Components/Alert`,component:u,argTypes:{variant:{control:`select`,options:[`info`,`success`,`warning`,`error`]}},decorators:[e=>(0,m.jsx)(`div`,{className:`max-w-lg`,children:e()})]},_={args:{variant:`info`,title:`Scheduled maintenance`,children:`Sunday 02:00–03:00 UTC.`}},v={args:{variant:`success`,title:`User created`,children:`Ada Lovelace was added.`}},y={args:{variant:`warning`,title:`Unusual sign-in activity`,children:`5 failed attempts.`}},b={name:`Error`,args:{variant:`error`,title:`Could not load users`,children:`Server unavailable.`}},x={args:{variant:`info`,title:`Tip`,children:`You can sort any column.`,onDismiss:h()}},S=[`Info`,`Success`,`Warning`,`ErrorVariant`,`Dismissible`],_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'info',
    title: 'Scheduled maintenance',
    children: 'Sunday 02:00–03:00 UTC.'
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'success',
    title: 'User created',
    children: 'Ada Lovelace was added.'
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'warning',
    title: 'Unusual sign-in activity',
    children: '5 failed attempts.'
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  name: 'Error',
  args: {
    variant: 'error',
    title: 'Could not load users',
    children: 'Server unavailable.'
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'info',
    title: 'Tip',
    children: 'You can sort any column.',
    onDismiss: fn()
  }
}`,...x.parameters?.docs?.source}}}})))()}C();export{x as Dismissible,b as ErrorVariant,_ as Info,v as Success,y as Warning,S as __namedExportsOrder,g as default};