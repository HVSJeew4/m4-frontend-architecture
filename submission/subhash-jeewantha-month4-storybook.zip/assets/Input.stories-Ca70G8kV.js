import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./jsx-runtime-4ahyPWF4.js";import{n,t as r}from"./Input-sw2R7tv0.js";var i,a,o,s,c,l,u,d,f;function p(){return(p=e((()=>{n(),i=t(),a={title:`Components/Input`,component:r,args:{label:`Name`},argTypes:{type:{control:`select`,options:[`text`,`email`,`password`,`search`]}},decorators:[e=>(0,i.jsx)(`div`,{className:`max-w-sm`,children:e()})]},o={args:{type:`text`,placeholder:`Ada Lovelace`}},s={args:{label:`Email`,type:`email`,autoComplete:`email`}},c={args:{label:`Password`,type:`password`,hint:`At least 8 characters.`}},l={args:{label:`Email`,type:`email`,defaultValue:`not-an-email`,error:`Invalid email address`}},u={args:{required:!0}},d={args:{disabled:!0,defaultValue:`Read only`}},f=[`Text`,`Email`,`Password`,`WithError`,`Required`,`Disabled`],o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    type: 'text',
    placeholder: 'Ada Lovelace'
  }
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Email',
    type: 'email',
    autoComplete: 'email'
  }
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Password',
    type: 'password',
    hint: 'At least 8 characters.'
  }
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Email',
    type: 'email',
    defaultValue: 'not-an-email',
    error: 'Invalid email address'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    required: true
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: 'Read only'
  }
}`,...d.parameters?.docs?.source}}}})))()}p();export{d as Disabled,s as Email,c as Password,u as Required,o as Text,l as WithError,f as __namedExportsOrder,a as default};