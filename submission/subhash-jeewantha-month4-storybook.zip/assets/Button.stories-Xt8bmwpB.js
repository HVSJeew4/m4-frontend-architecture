import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./jsx-runtime-4ahyPWF4.js";import{c as n,d as r,s as i}from"./icons-qBvd0GBy.js";import{n as a,t as o}from"./Button-BjL2GhCH.js";var s,c,l,u,d,f,p,m,h,g,_,v;function y(){return(y=e((()=>{a(),r(),s=t(),{fn:c}=__STORYBOOK_MODULE_TEST__,l={title:`Components/Button`,component:o,args:{children:`Click me`,onClick:c()},argTypes:{variant:{control:`select`,options:[`primary`,`secondary`,`danger`,`ghost`]},size:{control:`inline-radio`,options:[`sm`,`md`]}}},u={args:{variant:`primary`}},d={args:{variant:`secondary`}},f={args:{variant:`danger`,children:`Delete user`}},p={args:{isLoading:!0,children:`Saving…`}},m={args:{disabled:!0}},h={args:{size:`sm`}},g={args:{children:(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(i,{}),`Add user`]})}},_={args:{variant:`ghost`,"aria-label":`Delete user John Doe`,children:(0,s.jsx)(n,{})}},v=[`Primary`,`Secondary`,`Danger`,`Loading`,`Disabled`,`Small`,`WithIcon`,`IconOnly`],u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'primary'
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'secondary'
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'danger',
    children: 'Delete user'
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    isLoading: true,
    children: 'Saving…'
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'sm'
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    children: <>\r
        <PlusIcon />\r
        Add user\r
      </>
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'ghost',
    'aria-label': 'Delete user John Doe',
    children: <TrashIcon />
  }
}`,..._.parameters?.docs?.source},description:{story:`Icon-only: the accessible name comes from aria-label, as in the brief's delete button.`,..._.parameters?.docs?.description}}}})))()}y();export{f as Danger,m as Disabled,_ as IconOnly,p as Loading,u as Primary,d as Secondary,h as Small,g as WithIcon,v as __namedExportsOrder,l as default};