import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./jsx-runtime-4ahyPWF4.js";import{i as n,r}from"./react-DohMCLWR.js";import{a as i,o as a}from"./blocks-CyV3aHIa.js";function o(e){let t={code:`code`,h1:`h1`,li:`li`,p:`p`,strong:`strong`,ul:`ul`,...n(),...e.components};return(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(i,{title:`Introduction`}),`
`,(0,c.jsx)(t.h1,{id:`adminflow-component-library`,children:`AdminFlow component library`}),`
`,(0,c.jsxs)(t.p,{children:[`Reusable components for the AdminFlow dashboard. They live in `,(0,c.jsx)(t.code,{children:`src/components/common/`}),`, and each one
has its stories next to it (`,(0,c.jsx)(t.code,{children:`Button.tsx`}),` → `,(0,c.jsx)(t.code,{children:`Button.stories.tsx`}),`).`]}),`
`,(0,c.jsxs)(t.ul,{children:[`
`,(0,c.jsxs)(t.li,{children:[(0,c.jsx)(t.strong,{children:`Accessibility:`}),` every story is checked by the a11y addon (axe). Open the
"Accessibility" panel below a story to see the results.`]}),`
`,(0,c.jsxs)(t.li,{children:[(0,c.jsx)(t.strong,{children:`Styling:`}),` Tailwind CSS, the same styles as the app.`]}),`
`,(0,c.jsxs)(t.li,{children:[(0,c.jsx)(t.strong,{children:`Data:`}),` stories that need data use the app's mock API (MSW), so no backend is needed.`]}),`
`]})]})}function s(e={}){let{wrapper:t}={...n(),...e.components};return t?(0,c.jsx)(t,{...e,children:(0,c.jsx)(o,{...e})}):o(e)}var c;function l(){return(l=e((()=>{c=t(),r(),a()})))()}l();export{s as default};